
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtGui import QPixmap
from MainWindow import Ui_MainWindow
from PyQt5.QtCore import QDateTime,Qt,QTimer,QThread,pyqtSignal
from function import data_trans,barcode_comport_1,barcode_comport_2
from comport import Ui_Dialog
from threading import Timer
import sys
import threading
import time
import os
import serial
from datetime import date,datetime,timedelta
ser1 = serial.Serial(barcode_comport_1())
ser2= serial.Serial(barcode_comport_2()) 
serialdata = serial.Serial(data_trans(),19200)
#a = [1] 
#d = [1]
#f = [0]
#lis = [" "]
#lis1 = [" "]

class sensorThread(QThread):
       sensorSignal = pyqtSignal(str) 
       def __init__(self,  *args, **kwargs):
           super(sensorThread,self).__init__()           
           self.ser = serialdata
           self.STX = bytes.fromhex("02")
           self.ETX = bytes.fromhex("03")
           self.OK = "W1" 
           self.clear = "W0"          
           
             
       def write_serial_ok(self):
           time.sleep(0.5)                                            
           self.ser.write(self.STX)
           self.ser.write(self.OK.encode())           
           self.ser.write(self.ETX)
           self.ser.flushInput() 
                           
       def write_serial_clear(self):
           time.sleep(0.5)                                        
           self.ser.write(self.STX)
           self.ser.write(self.clear.encode())
           self.ser.write(self.ETX)
           self.ser.flushInput()  
           
    
          
           
class Bar1_Thread(QThread):
       barcodeSignal = pyqtSignal(str) 
       def __init__(self,  *args, **kwargs):
            super(Bar1_Thread, self).__init__()            
            self.ser1 = ser1     
       def run(self):           
                while True: 
                    try:
                        if self.ser1.is_open == True:
                          self.ser1.flushInput()  
                          ser_bytes = self.ser1.readline(16) 
#                          print (ser_bytes)
                          decoded_bytes = ser_bytes.decode("utf-8")  
#                          print (decoded_bytes)
                          self.barcodeSignal.emit(decoded_bytes[1:15])            
                          self.ser1.flushInput()
                        else:
                          self.ser1.open()
                          self.ser1.flushInput()  
                          ser_bytes = self.ser1.readline(16) 
#                          print (ser_bytes)
                          decoded_bytes = ser_bytes.decode("utf-8") 
#                          print (decoded_bytes)
                          self.barcodeSignal.emit(decoded_bytes[1:15])            
                          self.ser1.flushInput()
                    except serial.serialutil.SerialException :
                          self.ser1.close()
                          pass                      
                      
class Bar2_Thread(QThread):
       barcodeSignal = pyqtSignal(str) 
       def __init__(self,  *args, **kwargs):
            super(Bar2_Thread, self).__init__()            
            self.ser2 = ser2     
       def run(self):                                   
                while True:  
                       try:
                        if self.ser2.is_open == True:
                          self.ser2.flushInput()
                          ser_bytes = self.ser2.readline(15)
                          decoded_bytes = ser_bytes.decode("utf-8") 
                          self.barcodeSignal.emit(decoded_bytes[1:14])            
                          self.ser2.flushInput()  
                        else:
                          self.ser2.open()
                          self.ser2.flushInput()
                          ser_bytes = self.ser2.readline(15)
                          decoded_bytes = ser_bytes.decode("utf-8") 
                          self.barcodeSignal.emit(decoded_bytes[1:14])            
                          self.ser2.flushInput()                            
                       except serial.serialutil.SerialException:
                          self.ser2.close()
                          pass
                      


class MainWindow(QMainWindow, Ui_MainWindow):
      def __init__(self, *args, obj=None, **kwargs):
          super(MainWindow, self).__init__(*args, **kwargs)                                      
          self.setupUi(self) 
          
          self.date_time()
          self.bar_read1()
          self.bar_read2()
          self.result.setText("WAITING")
          self.result.setStyleSheet("color: rgb(170,255,255);")
          self.comport.clicked.connect(self.comport_set)
          self.reset.clicked.connect(self.reset_button)
          self.logclear.clicked.connect(self.log_clear)
          self.mrp_slno.textChanged.connect(self.mrp_barcode)
          self.ean_slno.textChanged.connect(self.ean_barcode)
#          self.result.textChanged.connect(self.line_stop)
          self.result.textChanged.connect(self.line_clear)
          
          
      def date_time(self):
          threading.Timer(1.0,self.date_time).start()
          currentdate=QDateTime.currentDateTime()
          time_label=currentdate.toString()         
          return self.label_3.setText(time_label) 
                      
      def comport_set(self):
          Dialog=QDialog()
          ui=Ui_Dialog()
          ui.setupUi(Dialog)
          Dialog.show()
          Dialog.exec_()
          
          
      def bar_read1(self):              
              self.thread1 = Bar1_Thread()  
              time.sleep(0.04)
              self.thread1.barcodeSignal.connect(self.mrp_slno.setText)          
              self.thread1.start() 
              
              
      def bar_read2(self):              
              self.thread2 = Bar2_Thread()  
              time.sleep(0.03)
              self.thread2.barcodeSignal.connect(self.ean_slno.setText)          
              self.thread2.start()    
                   
        
      def mrp_barcode(self):
          mrp=self.mrp_slno.text()
          mrp1 = mrp[0:14]
          ean=self.ean_slno.text()
          ean1 = ean[0:13]
          current_date = date.today()
          current_date_str = current_date.strftime("%d/%m/%Y")
          now = datetime.now()
          now_time = now.strftime("%H:%M:%S")
          if len(mrp1) == 14 and len(ean1) == 13:
              self.result.setText("PASS")
              self.result.setStyleSheet("color: rgb(85, 255, 0);")
              resul = self.result.text()
              log_data = "{},{},{},{},{},{}".format(current_date_str,now_time,mrp1,ean1,resul,"end")
              self.plainTextEdit.appendPlainText(log_data)
              path = 'Data_log/'
              file_name = "{}.txt".format(time.strftime("%Y-%m-%d"))
              filepath = os.path.join(path,file_name)
              with open(filepath,"a") as outfile:                       
                  outfile.write(log_data)
                  outfile.write('\n')               
                  outfile.close
              self.line_stop()  
              self.mrp_slno.setText("")
              self.ean_slno.setText("")
                  
          elif  len(mrp1) == 14 and len(ean) == 0:  
              self.result.setText("INPROGRESS")
              self.result.setStyleSheet("color: rgb(255, 255,0);")
              resul = self.result.text()
              log_data = "{},{},{},{},{},{}".format(current_date_str,now_time,mrp1,0,resul,"end")
              path = 'Temp_log/'
              file_name = "{}.txt".format(time.strftime("%Y-%m-%d"))
              filepath = os.path.join(path,file_name)
              with open(filepath,"a") as outfile:                       
                  outfile.write(log_data)
                  outfile.write('\n')               
                  outfile.close
                  
      def ean_barcode(self):
          mrp=self.mrp_slno.text()
          mrp1 = mrp[0:14]
          ean=self.ean_slno.text()
          ean1 = ean[0:13]
          current_date = date.today()
          current_date_str = current_date.strftime("%d/%m/%Y")
          now = datetime.now()
          now_time = now.strftime("%H:%M:%S")
          if len(mrp1) == 14 and len(ean1) == 13:
              self.result.setText("PASS")
              self.result.setStyleSheet("color: rgb(85, 255, 0);")
              resul = self.result.text()
              log_data = "{},{},{},{},{},{}".format(current_date_str,now_time,mrp1,ean1,resul,"end")
              self.plainTextEdit.appendPlainText(log_data)
              path = 'Data_log/'
              file_name = "{}.txt".format(time.strftime("%Y-%m-%d"))
              filepath = os.path.join(path,file_name)
              with open(filepath,"a") as outfile:                       
                  outfile.write(log_data)
                  outfile.write('\n')               
                  outfile.close
              self.line_stop()  
              self.mrp_slno.setText("")
              self.ean_slno.setText("")
                  
                  
          elif  len(mrp1) == 0 and len(ean1) == 13:  
              self.result.setText("INPROGRESS")
              self.result.setStyleSheet("color: rgb(255, 255,0);")
              resul = self.result.text()
              log_data = "{},{},{},{},{},{}".format(current_date_str,now_time,0,ean1,resul,"end")
              path = 'Temp_log/'
              file_name = "{}.txt".format(time.strftime("%Y-%m-%d"))
              filepath = os.path.join(path,file_name)
              with open(filepath,"a") as outfile:                       
                  outfile.write(log_data)
                  outfile.write('\n')               
                  outfile.close            

            
      def reset_button(self) :
          self.myserial1 = sensorThread()                          
          self.mrp_slno.setText("")
          self.ean_slno.setText("")
          self.result.setText("WAITING")
          self.result.setStyleSheet("color: rgb(170,255,255);")
          self.myserial1.write_serial_clear()
             
      def log_clear(self) :
           self.plainTextEdit.setPlainText("")
           
           
      def line_stop(self):          
          self.myserial1 = sensorThread() 
          result_status = self.result.text()
#          print (result_status)
          if result_status == "PASS":                        
              self.myserial1.write_serial_ok()   
              self.result.setText("WAITING")
              self.result.setStyleSheet("color: rgb(170,255,255);")                         
          else :
              pass
          
      def line_clear(self):          
          self.myserial1 = sensorThread() 
          result_status = self.result.text()
#          print (result_status)
          if result_status == "WAITING":                   
              self.myserial1.write_serial_clear()              
          else :
              pass     
                    
if  __name__=="__main__":   
    app = QApplication(sys.argv)
    window = MainWindow() 
    window.show()
    app.exec_()           