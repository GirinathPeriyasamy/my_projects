import serial


def code_availability(self):
    outfile = open("model.txt", 'r')
    model_list = [line.split(',') for line in outfile.readlines()] 
    bardata=self.Model_code_data.text()
    modelcode1=self.Model_Name_data.text()
    for i in model_list:        
        if i[0] == bardata or i[1] == modelcode1:            
           return True
           break        
    else :
          return False
      

def barcode_comport_1():
    outfile = open("comport.txt", 'r')
    port_list = [line.split(',') for line in outfile.readlines()]
    port = port_list[0][0].strip()
    return port

def barcode_comport_2():
    outfile = open("comport.txt", 'r')
    port_list = [line.split(',') for line in outfile.readlines()]
    port = port_list[0][1].strip()
    return port


def data_trans():
    outfile = open("comport.txt", 'r')
    port_list = [line.split(',') for line in outfile.readlines()]
    port = port_list[0][2].strip()
    return port

def barcodereader_1():    
    ser = serial.Serial(barcode_comport_1())
    while True:
          try:
              ser_bytes = ser.readline(16)
              decoded_bytes = ser_bytes.decode("utf-8")
              bardata = decoded_bytes[1:]              
              return bardata              
              ser.flushInput()                            
          except:              
              break
def barcodereader_2():    
    ser = serial.Serial(barcode_comport_2())
    while True:
          try:
              ser_bytes = ser.readline(15)
              decoded_bytes = ser_bytes.decode("utf-8")
              bardata = decoded_bytes[1:]              
              return bardata              
              ser.flushInput()                            
          except:              
              break
  