from PyQt5 import QtCore, QtGui, QtWidgets

class MyForm(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)

    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(400, 300)

        self.zoomInButton = QtWidgets.QToolButton(Form)
        self.zoomInButton.setGeometry(QtCore.QRect(20, 20, 40, 40))
        self.zoomInButton.setIcon(QtGui.QIcon("path_to_zoom_in_icon.png"))
        self.zoomInButton.setIconSize(QtCore.QSize(30, 30))
        self.zoomInButton.setAutoRaise(True)
        self.zoomInButton.setToolButtonStyle(QtCore.Qt.ToolButtonIconOnly)

        self.zoomOutButton = QtWidgets.QToolButton(Form)
        self.zoomOutButton.setGeometry(QtCore.QRect(70, 20, 40, 40))
        self.zoomOutButton.setIcon(QtGui.QIcon("path_to_zoom_out_icon.png"))
        self.zoomOutButton.setIconSize(QtCore.QSize(30, 30))
        self.zoomOutButton.setAutoRaise(True)
        self.zoomOutButton.setToolButtonStyle(QtCore.Qt.ToolButtonIconOnly)

        # Ensure the zoom buttons stay in front
        self.zoomInButton.raise_()
        self.zoomOutButton.raise_()

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    form = MyForm()
    form.show()
    sys.exit(app.exec_())
