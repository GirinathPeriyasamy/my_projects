from qgis.core import QgsProject, QgsPointXY, QgsTextAnnotation, QgsMapLayerStore
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont

for layer in QgsProject.instance().mapLayers().values():
    print(layer.name())
    

# Get the layer by its name or ID
layer = QgsProject.instance().mapLayersByName('gadm41_IND_0')[0]

# Define the coordinates and text for the annotation
x = 78.9629
y = 20.5937
text = 'Sample Annotation'

# Create an instance of QgsTextAnnotation and set its properties
annotation = QgsTextAnnotation()
annotation.setMapPosition(QgsPointXY(x, y))
annotation.setFrameColor(QColor(0, 0, 0))
annotation.setFrameWidth(1)
annotation.setFrameBackgroundColor(QColor(255, 255, 255, 200))
annotation.setMapLayer(layer)
annotation.setText(text)
annotation.setFont(QFont("Arial", 10))
annotation.setTextHorizontalAlignment(Qt.AlignHCenter)

# Add the annotation to the layer's annotation store
store = layer.annotationStore()
store.addAnnotation(annotation)

# Refresh the map canvas to display the annotation
iface.mapCanvas().refresh()
