from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import QtWidgets
from PyQt5.QtGui import QIcon, QPixmap
from qgis.core import QgsSvgMarkerSymbolLayer, QgsMarkerSymbol
from PyQt5.QtWidgets import QApplication, QMainWindow
from qgis.core import QgsPointXY, QgsCoordinateTransform, QgsCoordinateReferenceSystem
from PyQt5.QtWidgets import * #QVBoxLayout, QFileDialog, QMessageBox
from qgis.core import *
from qgis.gui import *
import sys
import os
# from qgis.core import QgsRubberBand, QgsWkbTypes, QgsGeometry, QgsPointXY
# from PyQt5.QtCore import Qt

from shapeviewer_gui import Ui_MainWindow
from view import Ui_View
from shape import Ui_Dialog

# Environment variable QGISHOME must be set to the install directory
# before running the application
qgis_prefix = "C:\\OSGeo4W\\apps\\qgis" #os.getenv("QGISHOME")

class ShapeViewer(QMainWindow, Ui_MainWindow, Ui_Dialog):

  def __init__(self):
    QMainWindow.__init__(self)

    # Required by Qt4 to initialize the UI
    self.setupUi(self)

    # Set the title for the app
    self.setWindowTitle("ShapeViewer")
    
    # Set status bar msg
    self.statusBar.showMessage("Developed by Azure Software Pvt. Ltd.")

    # Create the map canvas
    self.canvas = QgsMapCanvas()
    #self.canvas.useImageToRender(False) #QGIS2 code
    self.canvas.show()

    # Lay our widgets out in the main window using a 
    # vertical box layout
    self.layout = QVBoxLayout(self.frame)
    self.layout.addWidget(self.canvas)

    self.all_layers = []

    #Zoomin/Out/Pan - create the map tools
    self.toolPan = QgsMapToolPan(self.canvas)
    self.toolPan.setAction(self.actionPan)
    self.toolZoomIn = QgsMapToolZoom(self.canvas, False) # false = in
    self.toolZoomIn.setAction(self.actionZoom_in)
    self.toolZoomOut = QgsMapToolZoom(self.canvas, True) # true = out
    self.toolZoomOut.setAction(self.actionZoom_out)
    self.actionDot = QtWidgets.QAction(self.canvas)
    self.actionDot.setObjectName("actionDot")
    self.actionLine = QtWidgets.QAction(self.canvas)
    self.actionLine.setObjectName("actionLine")
    self.actionStar = QtWidgets.QAction(self.canvas)
    self.actionStar.setObjectName("actionStar")
    self.actionTriangle = QtWidgets.QAction(self.canvas)
    self.actionTriangle.setObjectName("actionTriangle")
    self.actionPolygon = QtWidgets.QAction(self.canvas)
    self.actionPolygon.setObjectName("actionPolygon")

    self.pan()

    self.connectSignalsSlots()

    #self.addLayerFromFile("..\\..\\download\\gadm41_IND_shp\\gadm41_IND_0.shp")
    #self.addLayerFromFile("..\\..\\download\\maps-master\\Districts\\Census_2011\\2011_Dist.shp")
    self.addLayerFromFile("..\\..\\download\\Delhi_Shapefiles\\delhi_administrative.shp")
    self.addLayerFromFile("..\\..\\download\\Delhi_Shapefiles\\delhi_highway.shp")
    # Create the custom pan tool

  def addDot(self):
    # Add the code to add a dot shape
    extent = self.canvas.extent()
    center = extent.center()
    x = center.x()
    y = center.y()
    x = self.clicked_x
    y = self.clicked_y
    # x = 10  # Change to the desired X coordinate
    # y = 1  # Change to the desired Y coordinate
    marker = QgsVertexMarker(self.canvas)
    marker.setCenter(QgsPointXY(x-1, y-1))
    marker.setColor(Qt.red)
    marker.setIconSize(5)
    marker.setIconType(QgsVertexMarker.ICON_BOX)
    marker.show()


  def addLine(self):
    # Add the code to add a line shape
    extent = self.canvas.extent()
    center = extent.center()
    x = center.x()
    y = center.y()

    # Define the line coordinates
    points = [
        QgsPointXY(x - 1, y + 5),
        QgsPointXY(x + 5, y + 5),
    ]

    line = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
    line.setToGeometry(QgsGeometry.fromPolylineXY(points), None)
    line.setColor(Qt.blue)
    line.setWidth(2)
    line.show()

  def addStar(self):
    # Add the code to add a dot shape
    extent = self.canvas.extent()
    center = extent.center()
    x = center.x()
    y = center.y()
    marker = QgsVertexMarker(self.canvas)
    marker.setCenter(QgsPointXY(x-2, y-2))
    marker.setColor(Qt.red)
    marker.setIconSize(25)
    marker.setIconType(QgsVertexMarker.ICON_X)
    marker.show()

  def addTriangle(self):
    # Add the code to add a triangle shape
    extent = self.canvas.extent()
    center = extent.center()
    x = center.x()
    y = center.y()
    # Reduce the size of the shape by modifying the coordinates
    scaling_factor = 0.25
    offset = 1*scaling_factor# Adjust this value to control the size reduction
    points = [
        QgsPointXY(x - offset, y - offset),
        QgsPointXY(x, y + offset),
        QgsPointXY(x + offset, y - offset),
        QgsPointXY(x - offset, y - offset),
    ]

    triangle = QgsRubberBand(self.canvas)
    triangle.setToGeometry(QgsGeometry.fromPolygonXY([points]), None)
    triangle.setColor(Qt.yellow)
    triangle.setWidth(2)
    triangle.show()


  def addPolygon(self):
    # Add the code to add a polygon shape
    extent = self.canvas.extent()
    center = extent.center()
    x = center.x()
    y = center.y()
    # Reduce the size of the shape by modifying the coordinates
    scaling_factor = 0.25
    offset = 1*scaling_factor# Adjust this value to control the size reduction
    points = [
        QgsPointXY(x - 8, y - offset),
        QgsPointXY(x - 8, y + offset),
        QgsPointXY(x - 7.5, y + offset),
        QgsPointXY(x - 7.5, y - offset),
    ]

    polygon = QgsRubberBand(self.canvas)
    polygon.setToGeometry(QgsGeometry.fromPolygonXY([points]), None)
    polygon.setColor(Qt.cyan)
    polygon.setWidth(2)
    polygon.show()


  def zoomIn(self):
    self.canvas.setMapTool(self.toolZoomIn)

  def zoomOut(self):
    self.canvas.setMapTool(self.toolZoomOut)

  def pan(self):
    self.canvas.setMapTool(self.toolPan)
  
  def connectSignalsSlots(self):
    self.actionExit.triggered.connect(self.close)
    self.actionOpen_Shapefile.triggered.connect(self.openShapeFile)
    self.actionOpen_OSM_file_pbf.triggered.connect(self.openOSMFile)
    self.actionZoom_in.triggered.connect(self.zoomIn)
    self.actionZoom_out.triggered.connect(self.zoomOut)
    self.actionPan.triggered.connect(self.pan)
    self.actionBrowserTreeView.triggered.connect(self.openFeatureWindow) #showActionMenu) #(browserTreeView)
    self.actionAbout.triggered.connect(self.aboutDlg)
    self.actionshape.triggered.connect(self.openShapeDialog)
    self.mMapLayerComboBox.layerChanged.connect(self.setTopLayer)
    self.canvas.mousePressEvent = self.canvasClicked



    
    # Connect the actions for adding shapes
    self.actionDot.triggered.connect(self.addDot)
    self.actionLine.triggered.connect(self.addLine)
    self.actionStar.triggered.connect(self.addStar)
    self.actionTriangle.triggered.connect(self.addTriangle)
    self.actionPolygon.triggered.connect(self.addPolygon)

    # Connect the actionOpen_Shapefile.triggered signal to activate the pan tool
  
  def canvasClicked(self, event):
    if event.button() == Qt.LeftButton:
        # Get the map coordinates of the clicked point
        map_point = self.canvas.getCoordinateTransform().toMapCoordinates(event.pos())
        self.clicked_x = map_point.x()
        self.clicked_y = map_point.y()
        # Print the coordinates
        print("Clicked Coordinate Point: ", map_point.x(), map_point.y())


  def addLayerFromFile(self, filename):
    fileInfo = QFileInfo(filename)

    # Add the layer
    layer = QgsVectorLayer(filename, fileInfo.fileName(), "ogr")

    if not layer.isValid():
      return

    # Add layer to the registry
    #QgsMapLayerRegistry.instance().addMapLayer(layer); #QGIS2 code
    QgsProject.instance().addMapLayer(layer)
    #QgsProject.instance().showAttributeTable(layer)

    # Set extent to the extent of our layer
    self.canvas.setExtent(layer.extent())
    self.all_layers.append(layer)
    print("ALL LAYERS:", self.all_layers)
    #self.all_layers = [layer]
    self.canvas.setLayers(self.all_layers) #QGIS2 code

  def setTopLayer(self):
    topLayer = self.mMapLayerComboBox.currentLayer()
    print("Selected Layer:", topLayer)
    # Get a list of all the map layers
    #layers = QgsMapLayerRegistry.instance().mapLayers().values()

    # Create a list to hold QgsMapCanvasLayer objects
    #self.all_layers = []

    # Iterate through the layers and create QgsMapCanvasLayer objects
    #for layer in layers:
    #    if layer != topLayer:
    #        self.all_layers.append(layer)
    #First layer is shown on top
    self.all_layers = [topLayer] + [i for i in self.all_layers if i != topLayer]
    print("ALL LAYERS(SET_TOP):", self.all_layers)

    # Set the layer order on the canvas
    self.canvas.setLayers(self.all_layers)

    # Refresh the canvas
    self.canvas.refresh()    


  def openShapeFile(self):
    # layout is set - open a layer
    # Add an OGR layer to the map
    file, _ = QFileDialog.getOpenFileName(self, 
                   "Open Shapefile", ".", "Shapefiles (*.shp)")
    self.addLayerFromFile(file)
    
  def openOSMFile(self):
    file, _ = QFileDialog.getOpenFileName(self, 
                   "Open OSM file", ".", "OSM files (*.pbf)")
    self.addLayerFromFile(file)

  def openShapeDialog(self):
        self.shapeDialog = QDialog()
        self.shapeUi = Ui_Dialog()
        self.shapeUi.setupUi(self.shapeDialog)
        self.shapeUi.buttonBox.accepted.connect(self.saveShape)
        self.shapeDialog.exec_()

  def saveShape(self):
        selectedShape = ""
        if self.shapeUi.Line.isChecked():
            selectedShape = "line"
        elif self.shapeUi.Dot.isChecked():
            selectedShape = "dot"
        elif self.shapeUi.Star.isChecked():
            selectedShape = "star"
        elif self.shapeUi.Triangle.isChecked():
            selectedShape = "Triangle"
        elif self.shapeUi.Polygon.isChecked():
            selectedShape = "Polygon"
        # Add more conditions for other shapes if needed

        # Perform the action based on the selected shape
        if selectedShape == "line":
            self.addLine()
        elif selectedShape == "dot":
            self.addDot()
        elif selectedShape == "star":
            self.addStar()
        elif selectedShape == "Triangle":
            self.addTriangle()
        elif selectedShape == "Polygon":
            self.addPolygon()
        # Add more actions for other shapes if needed

  def openFeatureWindow(self):
    self.featureWindow = QDialog()
    self.ui = Ui_View()
    self.ui.setupUi(self.featureWindow)
    self.featureWindow.exec_()

  def browserTreeView(self):    #Not working - crashing the appl 
    try:
        root = QgsProject.instance().layerTreeRoot()
        model = QgsLayerTreeModel(root)
        self.layerTreeView = QgsLayerTreeView()
        self.layerTreeView.setModel(model)
        self.layerTreeView.setObjectName("layerTreeView")
        self.gridLayout_2.addWidget(self.layerTreeView, 3, 0, 1, 1)
        self.layerTreeView.show()
    except Exception as e:
        print("Exception in browserTreeView")
        print(e)

  def showActionMenu(self):
    layer = self.all_layers[0] #self.canvas.currentLayer()
    if layer.actions().size() > 0:
        features = layer.dataProvider().getFeatures()
        feat1 = features.next()
        action_menu = QgsActionMenu(
            layer,
            feat1
        )
        print(feat1.id())

        action_menu.show()
        print(action_menu.actions())
        feat2 = features.next()
        action_menu.setFeature(feat2)
        print(feat2.id())
    else:
        print('No action for this layer')
    
  '''def addLine(self):    
    r = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)  # line
    points = [QgsPoint(-100, 45), QgsPoint(10, 60), QgsPoint(120, 45)]
    r.setToGeometry(QgsGeometry.fromPolyline(points), None)'''
    
  def alertDlg(self, msg=None):
    if msg is None:
      msg = "<p> Clicked </p>"
    QMessageBox.about(
            self,
            "Azure Software Pvt. Ltd.", #Title
            msg,  #Msg
        )
  
  def aboutDlg(self):
    QMessageBox.about(
            self,
            "About QGIS Demo",
            "<p>A sample  built with:</p>"
            "<p>QGIS Desktop 3.28.7 (qgis-ltr)</p"
            "<p>- Qt5 Version 5.15.3 and Qt Designer</p>"
            "<p>- Python Python 3.9.5 (compatible with QGIS 3.28</p>"
            "<p>by</p>"
            "<p>Azure Software Pvt. Ltd.</p>",
        )


def main(argv):
  # create Qt application
  app = QApplication(argv)

  # Initialize qgis libraries
  QgsApplication.setPrefixPath(qgis_prefix, True)
  QgsApplication.initQgis()

  # create main window
  wnd = ShapeViewer()
  # Move the app window to upper left
  wnd.move(100,100)
  wnd.show()

  # run!
  retval = app.exec_()
  
  # exit
  QgsApplication.exitQgis()
  sys.exit(retval)


if __name__ == "__main__":
  main(sys.argv)

