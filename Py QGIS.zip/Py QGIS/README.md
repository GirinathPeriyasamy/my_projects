Shapefileviewr.py - main source code
shapeviewer_gui.ui - UI created with QT Designer
shapeviewer_gui.py - file generated from the UI file using the following command from OSGeo4W shell
pyuic5 -o shapeviewer_gui.py shapeviewer_gui.ui

Use OSGeo4wShell
Assuming OSGeo4W installed in C:\OSGeo4W
Run the following commands.
C:\OSGeo4W>set PYTHONPATH=c:\OSGeo4W\apps\qgis-ltr\python
C:\OSGeo4W>set GDAL_DATA=C:\OSGeo4W\apps\gdal\share\gdal
C:\OSGeo4W>set S57_CSV=C:\OSGeo4W\share\gdal
[The last 2 are required for loading S-57 (ENC) files (*.000)

cd to D:\Technical\bitbucket\GIS\shapeviewer_1

D:\Technical\bitbucket\GIS\shapeviewer_1>python ShapeViewr.py

It opens a file open dialog box. Select a shape file 
(You may download shapefile for India from https://gadm.org/download_country.html)
Also copied in D:\Technical\GIS\download\gadm41_IND_shp dir.

