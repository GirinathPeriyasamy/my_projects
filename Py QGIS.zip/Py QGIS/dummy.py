from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5 import QtWidgets
from PyQt5.QtGui import QIcon, QPixmap
from qgis.core import QgsSvgMarkerSymbolLayer, QgsMarkerSymbol
from PyQt5.QtWidgets import QApplication, QMainWindow
from qgis.core import QgsPointXY, QgsCoordinateTransform, QgsCoordinateReferenceSystem
from PyQt5.QtWidgets import * #QVBoxLayout, QFileDialog, QMessageBox
from qgis.core import *
from qgis.gui import *
from qgis.core import QgsField, QgsVectorLayer, QgsPointXY, QgsGeometry, QgsFeature
import math
import sys
import os
from shapeviewer_gui import Ui_MainWindow
from view import Ui_View
from shape import Ui_Dialog
qgis_prefix = "C:\\OSGeo4W\\apps\\qgis-ltr" #os.getenv("QGISHOME")
class ShapeViewer(QMainWindow, Ui_MainWindow, Ui_Dialog):
  def __init__(self):
    QMainWindow.__init__(self)
    self.click_count = 0
    self.primx = 0
    self.primy = 0
    self.setupUi(self)
    self.setWindowTitle("ShapeViewer")
    self.statusBar.showMessage("Developed by Azure Software Pvt. Ltd.")
    self.canvas = QgsMapCanvas()
    self.canvas.show()
    self.layout = QVBoxLayout(self.frame)
    self.layout.addWidget(self.canvas)
    self.all_layers = []
    self.toolCoordinates = QgsMapToolEmitPoint(self.canvas)
    self.toolCoordinates.setAction(self.actionShow_location)
    self.toolPan = QgsMapToolPan(self.canvas)
    self.toolPan.setAction(self.actionPan)
    self.toolZoomIn = QgsMapToolZoom(self.canvas, False) # false = in
    self.toolZoomIn.setAction(self.actionZoom_in)
    self.toolZoomOut = QgsMapToolZoom(self.canvas, True) # true = out
    self.toolZoomOut.setAction(self.actionZoom_out)
    self.actionDot = QtWidgets.QAction(self.canvas)
    self.actionDot.setObjectName("actionDot")
    self.actionLine = QtWidgets.QAction(self.canvas)
    self.actionLine.setObjectName("actionLine")
    self.actionStar = QtWidgets.QAction(self.canvas)
    self.actionStar.setObjectName("actionStar")
    self.actionTriangle = QtWidgets.QAction(self.canvas)
    self.actionTriangle.setObjectName("actionTriangle")
    self.actionPolygon = QtWidgets.QAction(self.canvas)
    self.actionPolygon.setObjectName("actionPolygon")
    self.toolCoordinates.canvasClicked.connect(self.displayCoordinates)
    self.connectSignalsSlots()
    self.pan()
    self.addLayerFromFile("..\\gisdata\\Delhi_Shapefiles\\delhi_administrative.shp")
    self.addLayerFromFile("..\\gisdata\\Delhi_Shapefiles\\delhi_highway.shp")
    self.notelayer = QgsAnnotationLayer('Annotations', QgsAnnotationLayer.LayerOptions(QgsProject.instance().transformContext()))
    self.addLayerToCanvas(self.notelayer, set_layer_extend=False)

  def addDot(self):
    self.toolDot = PointTool(self.canvas, "dot")
    self.canvas.setMapTool(self.toolDot)

  def addLine(self):
    self.toolPoint = DistanceMapTool(self.canvas, line_only=True)
    self.canvas.setMapTool(self.toolPoint)

  def addTriangle(self):
    self.toolTriangle = PointTool(self.canvas, "triangle")
    self.canvas.setMapTool(self.toolTriangle)

  def addStar(self):
    self.toolStar = PointTool(self.canvas, "star")
    self.canvas.setMapTool(self.toolStar)

  def addPolygon(self):
    self.toolCircle = PointTool(self.canvas, "circle")
    self.canvas.setMapTool(self.toolCircle)

  def displayCoordinates(self, param):
    self.statusBar.showMessage("Developed by Azure Software Pvt. Ltd.\t\t" + str(param))
    print(param)

  def showCorodinates(self):
    self.canvas.setMapTool(self.toolCoordinates)

  def zoomIn(self):
    self.canvas.setMapTool(self.toolZoomIn)

  def zoomOut(self):
    self.canvas.setMapTool(self.toolZoomOut)

  def pan(self):
    self.canvas.setMapTool(self.toolPan)

  def drawPolygon(self):
    self.toolPolygon = PolyMapTool(self.canvas)
    self.canvas.setMapTool(self.toolPolygon)

  def drawRectange(self):
    self.toolRect = RectangleMapTool(self.canvas)
    self.canvas.setMapTool(self.toolRect)


  def distance_Bearing(self):
    self.toolDist = DistanceMapTool(self.canvas)
    self.canvas.setMapTool(self.toolDist)
     
  def perform_annotation(self):
      self.toolAnnot = Annotated(self.canvas, self.notelayer)
      self.canvas.setMapTool(self.toolAnnot)

  def connectSignalsSlots(self):
    self.actionExit.triggered.connect(self.close)
    self.actionOpen_Shapefile.triggered.connect(self.openShapeFile)
    self.actionOpen_Geo_Tiff.triggered.connect(self.openGeoTiffFile)
    self.actionOpen_S_57_file.triggered.connect(self.openS57File)
    self.actionOpen_OSM_file_pbf.triggered.connect(self.openOSMFile)
    self.actionShow_location.triggered.connect(self.showCorodinates)
    self.actionZoom_in.triggered.connect(self.zoomIn)
    self.actionZoom_out.triggered.connect(self.zoomOut)
    self.actionPan.triggered.connect(self.pan)
    self.actionDraw_Polygon.triggered.connect(self.drawPolygon)
    self.actionDraw_Rectangle.triggered.connect(self.drawRectange)
    self.actionAbout.triggered.connect(self.aboutDlg)
    self.actionShape.triggered.connect(self.openShapeDialog)
    self.actionDistance_calc.triggered.connect(self.distance_Bearing)
    self.actionclearscreen.triggered.connect(self.clearShapesAndMarkers)
    self.actionAdd_annotation.triggered.connect(self.perform_annotation)
    self.mMapLayerComboBox.layerChanged.connect(self.setTopLayer)
    self.actionDot.triggered.connect(self.addDot)
    self.actionLine.triggered.connect(self.addLine)
    self.actionStar.triggered.connect(self.addStar)
    self.actionTriangle.triggered.connect(self.addTriangle)
    self.actionPolygon.triggered.connect(self.addPolygon)  
    self.pushButtonRemoveLayer.clicked.connect(self.removeLayer)
    self.actionAdd_arrowline_Symbol.triggered.connect
    self.actionBrowserTreeView.triggered.connect(self.addWayPointsFromCSV) #openFeatureWindow) #showActionMenu) #(browserTreeView)

  def addLayerToCanvas(self, layer, set_layer_extend=True):
    QgsProject.instance().addMapLayer(layer)
    if set_layer_extend is True:
        self.canvas.setExtent(layer.extent())
    self.all_layers.append(layer)
    self.canvas.setLayers(self.all_layers) #QGIS2 code
  
  def removeLayer(self):
    print("removeLayer Before", self.all_layers)
    rem_layer = self.all_layers[0]
    self.all_layers = self.all_layers[1:]
    QgsProject.instance().removeMapLayers( [rem_layer.id()] )
    print("removeLayer After", self.all_layers)
  
  def addLayerFromFile(self, filename, layername=None):
    fileInfo = QFileInfo(filename)

    layer = None
    if layername is None:
      print("addLayerFromFile Opening:", filename)
      layer = QgsVectorLayer(filename, fileInfo.fileName(), "ogr")
    else:
      print("addLayerFromFile Opening:", filename+layername)
      layer = QgsVectorLayer(filename+layername, fileInfo.fileName(), "ogr")

    if not layer.isValid():
      print("addLayerFromFile: Invalid layer for:", filename) #, layer.error().summary())
      return

    print("addLayerFromFile: valid layer for:", filename)
    self.addLayerToCanvas(layer)

  def addLayersFromS57File(self, filename, layername=None):
    fileInfo = QFileInfo(filename)

    # Add the layer
    layer = None
    if layername is not None:
      print("addLayersFromS57File Opening:", filename+layername)
      layer = QgsVectorLayer(filename+layername, fileInfo.fileName(), "ogr")
      if not layer.isValid():
        print("addLayersFromS57File: Invalid layer for:", filename) #, layer.error().summary())
        return

      print("addLayersFromS57File: valid layer for:", filename)
      self.addLayerToCanvas(layer)
      return
      
    print("addLayersFromS57File Opening (for query):", filename)    
    basename = fileInfo.fileName()
    layer = QgsVectorLayer(filename, basename, "ogr")
    if not layer.isValid(): #if the layer is invalid 
      print("addLayersFromS57File: Invalid layer (Query) for:", filename) #, layer.error().summary())
      return

    layer.setProviderEncoding(" System ")       #Set the encoding format of the layer 
    sublayers = layer.dataProvider().subLayers()#Get user selection The string names of all sublayers contained in the electronic chart 
    subLayersCount = len(sublayers)             #If the newly created layer has more than 1 layer of data available, we show the sublayers selection dialog so the user can select the sublayers to actually load. 
    if subLayersCount >= 1:
      for i in range(0, subLayersCount):
        print("SubLayer[", i, "]:", sublayers[i])
        sLayerDefs = sublayers[i].split( '!!::!!' )
        composedURI = filename + "|layerid=" + sLayerDefs[0]
        layerName = basename+ " @ " +sLayerDefs[1];
 
        layerGeometryType = sLayerDefs[3] #layer type
 
        if layerGeometryType in ("Polygon", "Point", "LineString"): 
          composedURI = composedURI + "|geometrytype=" + layerGeometryType #Set the full string name of the chart sublayer 
          layerTemp = QgsVectorLayer(composedURI, layerName, "ogr")

          if not layerTemp.isValid(): # If the layer is invalid 
            print("addLayersFromS57File: Invalid Sublayer for:", composedURI) #, layer.error().summary())
            return
          self.addLayerToCanvas(layerTemp)
    print("End open S-57 file")
    return
    
  def addRasterLayerFromFile(self, filename, layername=None):
    print("In addRasterLayerFromFile:", filename)
    fileInfo = QFileInfo(filename)

    # Add the layer
    layer = None
    if layername is None:
      layer = QgsRasterLayer(filename, fileInfo.fileName(), "gdal")
    else:
      print("addRasterLayerFromFile Opening:", filename+layername)
      layer = QgsRasterLayer(filename+layername, fileInfo.fileName(), "gdal")

    if not layer.isValid():
      print("addRasterLayerFromFile: Invalid layer for:", filename, layer.error().summary())
      return
      
    print("addRasterLayerFromFile: valid layer for:", filename)
    self.addLayerToCanvas(layer)

  def setTopLayer(self):
    topLayer = self.mMapLayerComboBox.currentLayer()
    print("Selected Layer:", topLayer)
    if topLayer is None:
        return
    self.all_layers = [topLayer] + [i for i in self.all_layers if i != topLayer]
    self.canvas.setLayers(self.all_layers)
    self.canvas.setExtent(topLayer.extent())
    self.canvas.refresh()    

  def openShapeFile(self):
    file, _ = QFileDialog.getOpenFileName(self, 
                   "Open Shapefile", ".", "Shapefiles (*.shp)")
    self.addLayerFromFile(file)
  
  def openS57File(self):
    file, _ = QFileDialog.getOpenFileName(self, 
                   "Open S-57 file", ".", "S-57 file (*.000)")   
    self.addLayersFromS57File(file) #Works with ..\\gisdata\\US5TX51M.000    
  
  def openGeoTiffFile(self):
    file, _ = QFileDialog.getOpenFileName(self, 
                   "Open GeoTiff file", ".", "Tiff files (*.tif)")
    self.addRasterLayerFromFile(file)
        
  def openOSMFile(self):
    file, _ = QFileDialog.getOpenFileName(self, 
                   "Open OSM file", ".", "OSM files (*.pbf)")
    self.addLayerFromFile(file)

  def openShapeDialog(self):
        self.shapeDialog = QDialog()
        self.shapeUi = Ui_Dialog()
        self.shapeUi.setupUi(self.shapeDialog)
        self.shapeUi.buttonBox.accepted.connect(self.saveShape)
        self.shapeDialog.exec_()

  def saveShape(self):
        selectedShape = ""
        if self.shapeUi.Line.isChecked():
            selectedShape = "line"
        elif self.shapeUi.Dot.isChecked():
            selectedShape = "dot"
        elif self.shapeUi.Star.isChecked():
            selectedShape = "star"
        elif self.shapeUi.Triangle.isChecked():
            selectedShape = "Triangle"
        elif self.shapeUi.Polygon.isChecked():
            selectedShape = "Polygon"

        print("saveShape:", selectedShape)
        
        if selectedShape == "line":
            self.addLine()
        elif selectedShape == "dot":
            self.addDot()
        elif selectedShape == "star":
            self.addStar()
        elif selectedShape == "Triangle":
            self.addTriangle()
        elif selectedShape == "Polygon":
            self.addPolygon()

  def clearShapesAndMarkers(self):
        items = self.canvas.scene().items()
        for item in items:
            if isinstance(item, QgsRubberBand) or isinstance(item, QgsVertexMarker):
                self.canvas.scene().removeItem(item)
        
        self.canvas.refresh()

  def addArrowLineSymbols(self):
    association_symbol = QgsApplication.symbolLayerRegistry().symbolLayerMetadata("ArrowLine").createSymbolLayer({
        'arrow_width': '0.4',
        'head_length': '2.0',
        'head_thickness' : '0.75',
        'color': 'red',
        'line_color': 'red',
        'is_curved': '0',
        'arrow_start_width': '.2'
    })
    road_object_path_association_layer = self.all_layers[0]
    road_object_path_association_layer.renderer().symbol().appendSymbolLayer(association_symbol)
    road_object_path_association_layer.triggerRepaint() # Add repaint layer

  def addWayPointsFromCSV(self):
    csv_path = './Delhi_waypoints.csv'
    csv_layer_name = 'CSV Data'
    fields = [
        QgsField('label', QVariant.String),
        QgsField('latitude', QVariant.Double),
        QgsField('longitude', QVariant.Double),
    ]
    csv_layer = QgsVectorLayer('Point?crs=EPSG:4326', csv_layer_name, 'memory')
    csv_layer_data = []

    with open(csv_path, 'r') as csv_file:
        for line in csv_file:
            print("LINE:", line) 
            label, latitude, longitude = line.strip().split(',')
            feature = QgsFeature()
            feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(float(longitude), float(latitude))))
            print("Giri")
            feature.setAttributes([label, float(latitude), float(longitude)])
            csv_layer_data.append(feature)
          
    csv_layer.startEditing()
    csv_layer.dataProvider().addFeatures(csv_layer_data)
    csv_layer.updateExtents()
    csv_layer.commitChanges()
    
    # Add the layer to the map canvas
    QgsProject.instance().addMapLayer(csv_layer)
    
    # Set the extent of the map canvas to match the CSV layer
    canvas = self.canvas
    canvas.setExtent(csv_layer.extent())
    canvas.refresh()

  def openFeatureWindow(self):
    self.featureWindow = QDialog()
    self.ui = Ui_View()
    self.ui.setupUi(self.featureWindow)
    self.featureWindow.exec_()
  
  def featureTool(self):
    def callback(feature):
        """Code called when the feature is selected by the user"""
        print("You clicked on feature {}".format(feature.id()))

    #canvas = iface.mapCanvas()
    self.feature_identifier = QgsMapToolIdentifyFeature(self.canvas)

    # indicates the layer on which the selection will be done
    vlayer = self.all_layers[0]
    self.feature_identifier.setLayer(vlayer)

    # use the callback as a slot triggered when the user identifies a feature
    self.feature_identifier.featureIdentified.connect(callback)

    # activation of the map tool
    self.canvas.setMapTool(self.feature_identifier)

  def browserTreeView(self):    #Not working - crashing the appl 
    try:
        root = QgsProject.instance().layerTreeRoot()
        model = QgsLayerTreeModel(root)
        self.layerTreeView = QgsLayerTreeView()
        self.layerTreeView.setModel(model)
        self.layerTreeView.setObjectName("layerTreeView")
        self.gridLayout_2.addWidget(self.layerTreeView, 3, 0, 1, 1)
        self.layerTreeView.show()
    except Exception as e:
        print("Exception in browserTreeView")
        print(e)

  def showActionMenu(self):
    layer = self.all_layers[0] #self.canvas.currentLayer()
    if layer.actions().size() > 0:
        features = layer.dataProvider().getFeatures()
        feat1 = features.next()
        action_menu = QgsActionMenu(
            layer,
            feat1
        )
        print(feat1.id())

        action_menu.show()
        print(action_menu.actions())
        feat2 = features.next()
        action_menu.setFeature(feat2)
        print(feat2.id())
    else:
        print('No action for this layer')

  def alertDlg(self, msg=None):
    if msg is None:
      msg = "<p> Clicked </p>"
    QMessageBox.about(
            self,
            "Azure Software Pvt. Ltd.", #Title
            msg,  #Msg
        )
    
  def aboutDlg(self):
    QMessageBox.about(
            self,
            "About QGIS Demo",
            "<p>A sample  built with:</p>"
            "<p>QGIS Desktop 3.28.7 (qgis-ltr)</p"
            "<p>- Qt5 Version 5.15.3 and Qt Designer</p>"
            "<p>- Python Python 3.9.5 (compatible with QGIS 3.28</p>"
            "<p>by</p>"
            "<p>Azure Software Pvt. Ltd.</p>",
        )


class PolyMapTool(QgsMapToolEmitPoint):
    def __init__(self, canvas):
        self.canvas = canvas
        QgsMapToolEmitPoint.__init__(self, self.canvas)
        self.rubberband = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rubberband.setColor(QColor(Qt.red))
        self.rubberband.setFillColor(QColor(210, 153, 90, 125))
        self.rubberband.setWidth(1)
        self.points = []
        self.m = QgsVertexMarker(self.canvas)
        self.deactivated.connect(self.tool_deactivated)

    def canvasPressEvent(self, e):
        point = self.toMapCoordinates(e.pos())
        self.m.setCenter(point)
        self.m.setColor(QColor(0,255,0))
        self.m.setIconSize(5)
        self.m.setIconType(QgsVertexMarker.ICON_BOX)
        self.m.setPenWidth(3)
        self.points.append(point)
        self.isEmittingPoint = True
        self.showPoly()

    def showPoly(self):
        self.rubberband.reset(QgsWkbTypes.PolygonGeometry)
        for point in self.points[:-1]:
            self.rubberband.addPoint(point, False)
        self.rubberband.addPoint(self.points[-1], True)
        self.rubberband.show()

    def tool_deactivated(self):
        return


class DistanceMapTool(QgsMapToolEmitPoint):
  def __init__(self, canvas, line_only=False):
    self.canvas = canvas
    self.line_only = line_only
    QgsMapToolEmitPoint.__init__(self, self.canvas)
    self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
    self.rubberBand.setColor(Qt.red)
    self.rubberBand.setWidth(1)
    self.reset()

  def reset(self):
    self.startPoint = self.endPoint = None
    self.isEmittingPoint = False
    self.rubberBand.reset(QgsWkbTypes.LineGeometry)

  def canvasPressEvent(self, e):
    self.startPoint = self.toMapCoordinates(e.pos())
    self.endPoint = self.startPoint
    self.isEmittingPoint = True
    self.showLine(self.startPoint, self.endPoint)

  def canvasReleaseEvent(self, e):
    self.isEmittingPoint = False
    r = self.rectangle()
    if r is not None:
      print("Rectangle:", r.xMinimum(),
            r.yMinimum(), r.xMaximum(), r.yMaximum()
           )
    x1 = self.startPoint.x()
    y1 = self.startPoint.y()
    x2 = self.endPoint.x()
    y2 = self.endPoint.y()
    
    if self.line_only is False:
        distance, bearing = self.calculateDistance(x1,y1,x2,y2)
        msg = f"The distance between the two points is: {distance:.2f} km"
        msg2 = f"The bearing between the two points is: {bearing:.2f} RAD (clockwise from N)"
        QMessageBox.information(self.canvas, "Distance & bearing", msg + "\n" + msg2)
        print(distance)
        print("Distance between points:", distance)


  def canvasMoveEvent(self, e):
    if not self.isEmittingPoint:
      return

    self.endPoint = self.toMapCoordinates(e.pos())
    self.showLine(self.startPoint, self.endPoint)

  def calculateDistance(self, x1, y1, x2, y2):
    point1 = QgsPointXY(x1, y1)
    point2 = QgsPointXY(x2, y2)
    d = QgsDistanceArea()
    d.setEllipsoid('WGS84')
    distance_meter = d.measureLine([point1, point2])
    bearing = d.bearing(point1, point2)
    distance=distance_meter/1000
    return distance, bearing


  def showLine(self, startPoint, endPoint):
    self.rubberBand.reset(QgsWkbTypes.LineGeometry)
    if startPoint.x() == endPoint.x() and startPoint.y() == endPoint.y():
      return

    point1 = QgsPointXY(startPoint.x(), startPoint.y())
    point2 = QgsPointXY(endPoint.x(), endPoint.y())
    points = [point1, point2]
    self.rubberBand.setToGeometry(QgsGeometry.fromPolylineXY(points), None)
    self.rubberBand.show()

  def rectangle(self):
    if self.startPoint is None or self.endPoint is None:
      return None
    elif (self.startPoint.x() == self.endPoint.x() and \
          self.startPoint.y() == self.endPoint.y()):
      return None
      points = [
          QgsPointXY(x, y),
          QgsPointXY(x1, y1),
      ]
      return QgsRectangle(self.startPoint, self.endPoint)

  def deactivate(self):
    QgsMapTool.deactivate(self)
    self.deactivated.emit()

class RectangleMapTool(QgsMapToolEmitPoint):
  def __init__(self, canvas):
    self.canvas = canvas
    QgsMapToolEmitPoint.__init__(self, self.canvas)
    self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
    self.rubberBand.setColor(Qt.red)
    self.rubberBand.setWidth(1)
    self.reset()

  def reset(self):
    self.startPoint = self.endPoint = None
    self.isEmittingPoint = False
    self.rubberBand.reset(QgsWkbTypes.PolygonGeometry)

  def canvasPressEvent(self, e):
    self.startPoint = self.toMapCoordinates(e.pos())
    self.endPoint = self.startPoint
    self.isEmittingPoint = True
    self.showRect(self.startPoint, self.endPoint)

  def canvasReleaseEvent(self, e):
    self.isEmittingPoint = False
    r = self.rectangle()
    if r is not None:
      print("Rectangle:", r.xMinimum(),
            r.yMinimum(), r.xMaximum(), r.yMaximum()
           )

  def canvasMoveEvent(self, e):
    if not self.isEmittingPoint:
      return

    self.endPoint = self.toMapCoordinates(e.pos())
    self.showRect(self.startPoint, self.endPoint)

  def showRect(self, startPoint, endPoint):
    self.rubberBand.reset(QgsWkbTypes.PolygonGeometry)
    if startPoint.x() == endPoint.x() or startPoint.y() == endPoint.y():
      return

    point1 = QgsPointXY(startPoint.x(), startPoint.y())
    point2 = QgsPointXY(startPoint.x(), endPoint.y())
    point3 = QgsPointXY(endPoint.x(), endPoint.y())
    point4 = QgsPointXY(endPoint.x(), startPoint.y())

    self.rubberBand.addPoint(point1, False)
    self.rubberBand.addPoint(point2, False)
    self.rubberBand.addPoint(point3, False)
    self.rubberBand.addPoint(point4, True)    # true to update canvas
    self.rubberBand.show()

  def rectangle(self):
    if self.startPoint is None or self.endPoint is None:
      return None
    elif (self.startPoint.x() == self.endPoint.x() or \
          self.startPoint.y() == self.endPoint.y()):
      return None

      return QgsRectangle(self.startPoint, self.endPoint)

  def deactivate(self):
    QgsMapTool.deactivate(self)
    self.deactivated.emit()

class CustomMarker(QgsVertexMarker):
    def __init__(self, canvas):
        super(CustomMarker, self).__init__(canvas)
        self.canvas = canvas
        self.event_filter = CanvasEventFilter(self)
        self.canvas.viewport().installEventFilter(self.event_filter)
        self.dragStarted = False

    def mousePressEvent(self, event):
        print("---MOUSE EVENT---")
        if event.button() == Qt.LeftButton:
            print("Left click")
            self.dragStarted = True
            
    def mouseReleaseEvent(self, event):
        print("---MOUSE EVENT--- Release")
        self.dragStarted = False
        
    def mouseMoveEvent(self, event):
        if self.dragStarted:
            print("Moved")
            self.start_point = self.toMapCoordinates(event.pos())
            self.setCenter(self.start_point)
            self.show()

class CanvasEventFilter(QObject):
    
    def __init__(self, marker):
        self.marker = marker
        super(CanvasEventFilter, self).__init__()
        
    def eventFilter(self, obj, event):
        if self.marker.isUnderMouse():
            if event.type() == QEvent.MouseButtonPress:
                self.marker.mousePressEvent(event)
            elif event.type() == QEvent.MouseButtonRelease:
                self.marker.mouseReleaseEvent(event)
            elif event.type() == QEvent.MouseMove:
                self.marker.mouseMoveEvent(event)
        return False

class PointTool(QgsMapTool):   
    def __init__(self, canvas, symbol_type):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas    
        self.symbol_type = symbol_type

    def canvasPressEvent(self, event):
        x = event.pos().x()
        y = event.pos().y()

        self.start_point = self.toMapCoordinates(event.pos())
        print("Clicked:", self.symbol_type)
        pass

    def canvasMoveEvent(self, event):
        x = event.pos().x()
        y = event.pos().y()

        self.start_point = self.toMapCoordinates(event.pos())

    def canvasReleaseEvent(self, event):
        def paintDot(self,point):
          marker = CustomMarker(self.canvas) #QgsVertexMarker
          marker.setCenter(point)
          marker.setColor(Qt.red)
          marker.setIconSize(5)
          marker.setIconType(QgsVertexMarker.ICON_BOX)
          marker.show()
        def paintStar(self,point):
          marker = QgsVertexMarker(self.canvas)
          marker.setCenter(point)
          marker.setColor(Qt.red)
          marker.setIconSize(25)
          marker.setIconType(QgsVertexMarker.ICON_X)
          marker.show()

        def paintTriangle(self,inp1,inp2):
          x = inp1
          y = inp2
          scaling_factor = 0.25
          offset = 0.25*scaling_factor# Adjust this value to control the size reduction
          points = [
              QgsPointXY(x - offset, y - offset),
              QgsPointXY(x, y + offset),
              QgsPointXY(x + offset, y - offset),
              QgsPointXY(x - offset, y - offset),
          ]
          triangle = QgsRubberBand(self.canvas)
          triangle.setToGeometry(QgsGeometry.fromPolygonXY([points]), None)
          triangle.setColor(Qt.yellow)
          triangle.setWidth(2)
          triangle.show()
        
        def paintCircle(self, inp1, inp2):
          item = CircleCanvasItem(self.canvas)
          item.setCenter(QgsPointXY(inp1, inp2))
          item.setSize(5)
          item.show()

        #Get the click
        print("Released:", self.symbol_type)
        self.start_point = self.toMapCoordinates(event.pos())
        if self.symbol_type == "dot":
            print("Drawing dot:", self.start_point)
            paintDot(self, self.start_point)
        elif self.symbol_type == "star":
            print("Drawing start:", self.start_point)
            paintStar(self, self.start_point)
        elif self.symbol_type == "triangle":
            print("Drawing triangle:", self.start_point)
            paintTriangle(self, self.start_point.x(), self.start_point.y())
        elif self.symbol_type == "circle":
            print("Drawing circle:", event.pos()) #self.start_point)
            paintCircle(self, event.pos().x(), event.pos().y())

    def activate(self):
        pass

    def deactivate(self):
        pass

    def isZoomTool(self):
        return False

    def isTransient(self):
        return False

    def isEditTool(self):
        return True

class CircleCanvasItem(QgsMapCanvasItem):
  def __init__(self, canvas):
    super().__init__(canvas)
    self.center = QgsPoint(0, 0)
    self.size   = 100

  def setCenter(self, center):
    self.center = center

  def center(self):
    return self.center

  def setSize(self, size):
    self.size = size

  def size(self):
    return self.size

  def boundingRect(self):
    return QRectF(self.center.x() - self.size/2,
      self.center.y() - self.size/3,
      self.center.x() + self.size/2,
      self.center.y() + self.size/3)

  def paint(self, painter, option, widget):
    path = QPainterPath()
    path.moveTo(self.center.x(), self.center.y());
    path.arcTo(self.boundingRect(), 0.0, 360.0)
    painter.fillPath(path, QColor("blue"))
#-----------------------------------------------------------------------
class AnnotationInputDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Enter Annotation Text")
        
        layout = QVBoxLayout(self)
        self.text_input = QLineEdit()
        layout.addWidget(self.text_input)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def get_annotation_text(self):
        return self.text_input.text()

class Annotated(QgsMapToolEmitPoint):
    def __init__(self, canvas, ann):
        super().__init__(canvas)
        self.canvas = canvas
        self.annotation_layer = ann

    def canvasReleaseEvent(self, event):
        point = event.mapPoint()
        dialog = AnnotationInputDialog(self.canvas)
        if dialog.exec_() == QDialog.Accepted:
            annotation_text = dialog.get_annotation_text()
            a = QgsAnnotationPointTextItem(annotation_text, point)
            self.annotation_layer.addItem(a)
            return

def main(argv):
  app = QApplication(argv)

  QgsApplication.setPrefixPath(qgis_prefix, True)
  QgsApplication.initQgis()

  wnd = ShapeViewer()
  wnd.move(100,100)
  wnd.show()

  # run!
  retval = app.exec_()
  
  # exit
  QgsApplication.exitQgis()
  sys.exit(retval)


if __name__ == "__main__":
  main(sys.argv)

