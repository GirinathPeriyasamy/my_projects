#include<16f877a.h>
#fuses HS,NOWDT,NOPROTECT,NOLVP
#device ADC = 10
#use delay(clock=20000000)
#include"lcd.h"
#use rs232(baud = 9600, xmit=PIN_C6,rcv=PIN_C7)



/*/////////////////////////////////////////////////////

V = 12V, I = 0.16A.

      P = VI.  V = IR.  so R = V/I
      
      R = 12/0.16 = 75;
      
      So. V = 12, R = 75, I = 0.16A
      
      Measured Current = Measured Volt / R

////////////////////////////////////////////////////*/

void digit_conv_01(unsigned long int,unsigned int,unsigned long int);
void digit_conv_21(unsigned long int,unsigned int,unsigned long int);
void digit_conv_22(unsigned long int,unsigned int,unsigned long int);

unsigned long int rise,fall,pulse_width,cycle,one_rev,rpm;
unsigned long int i; //curr_check_new = 0;
unsigned long int adc_value_volt,adc_value_curr,curr_check,curr_check_old,curr_tot,curr_final;
unsigned long int measured_curr1,measured_volt1;
int count = 0;
int send = 0;
float measured_volt,measured_curr;
float ms_conv;

//float measured_curr_ratio,measured_curr_ratio_old;

#int_ccp2
void isr()
{
   rise = CCP_1;
   fall = CCP_2;

   pulse_width = fall - rise; 

}


void main()
{
   set_tris_d(0);
   set_tris_e(0);
   //set_tris_b(0x0f);
   setup_ccp1(CCP_CAPTURE_RE);    // Configure CCP1 to capture rise
   setup_ccp2(CCP_CAPTURE_FE);    // Configure CCP2 to capture fall
   setup_timer_1(T1_INTERNAL);    // Start timer 1

   enable_interrupts(INT_CCP2);   // Setup interrupt on falling edge
   enable_interrupts(GLOBAL);
   
   setup_adc(ADC_CLOCK_INTERNAL);
   setup_adc_ports( RA0_RA1_ANALOG_RA3_REF );
   output_bit(pin_e2,0);
   output_bit(pin_B7,0);
    //output_bit(pin_b4,1);
    //output_bit(pin_b0,1);
    //output_bit(pin_b1,0);
   lcd_init();
   lcd_cmd(0x82);
   lcd_data("RPM & CURRENT");
   lcd_cmd(0xC4);
   lcd_data("CHECKING");
   //output_b(0x00);
    
   while(true)
   {
           
      for(i=0;i<10;i++)
      {
         set_adc_channel(1);
         delay_us(10);
         adc_value_curr = read_adc();
         curr_check = (float)(adc_value_curr * (5.0/1024.0)) * 1000;
         curr_check_old = curr_check + curr_tot;
         curr_tot = curr_check_old;
         count++;           
      }       
      curr_final = curr_tot/count;
     // printf("Curr_final =%lu\r\n",curr_final);
      count=0;
      curr_tot=0;
      curr_check_old=0;
               
      if(curr_final == 0)
      {
         send = 1;        
         delay_ms(2000);
         
      }
      if((curr_final > 50) && (curr_final < 120))
      //if(curr_final >= 156)
      {
         if(send == 1)
         {
            output_bit(pin_B1,1);  // RED LED ON
            output_bit(pin_B2,0);  //GREEN LED OFF
            //output_bit(pin_B3,0);  // BUZZER OFF
            
            lcd_cmd(0x80);
            lcd_data("      WAIT      ");
           
            lcd_cmd(0xC0);
            lcd_data("....TESTING.....");
            
            
            
         }
      }
        
  /////////////***** Single Fan Mode *****/////////////
  
      if(input(pin_B0) == 0)
      {
      //output_bit(pin_B7,0);
      //output_bit(pin_B1,1);  // RED LED ON
      //output_bit(pin_B2,0);  //GREEN LED OFF
            //lcd_cmd(0xC0);
            //lcd_data("....1TESTING....");
         if((curr_check >= 120) && (curr_check <= 160))
         {
            output_bit(pin_B7,0);
            if(send == 1)
            {
            //output_bit(pin_B1,1);  // RED LED ON
            //output_bit(pin_B2,0);  //GREEN LED OFF
            //output_bit(pin_B3,0);  // BUZZER OFF
               for(i=0;i<3000;i++)
               {                                 
             ///  Volt Checking  ///
                  set_adc_channel(0);
                  delay_us(10);
                  adc_value_volt = read_adc();     
                  measured_volt = (adc_value_volt * ((12.00)/(1023.00)));
                  measured_volt1 = measured_volt * 100;
                  
            /// Current Checking ///                                   
                  measured_curr = measured_volt/75;
                  measured_curr1 = measured_curr * 1000;
                                                                                                                           
            /// RPM Checking  ///     
                  cycle = pulse_width/5;
                  one_rev = cycle*4;
                  ms_conv = (float)one_rev/1000000;
                  rpm = (60/ms_conv);
                  //send = 1;           
               }
               digit_conv_01(measured_volt1, curr_check,rpm);
               send = 0;
               
               output_bit(pin_B1,0);  // RED LED OFF
               output_bit(pin_B2,1);  //GREEN LED ON
               //output_bit(pin_B3,1);  // BUZZER ON
               //delay_ms(2000);
               //output_bit(pin_B3,0);  // BUZZER ON
            }
         }
      }
     
/////////////***** Double Fan Mode *****/////////////   

      if(input(pin_B0) == 1)
      {
      //output_bit(pin_B7,1);
      //output_bit(pin_B1,0);  // RED LED ON
      //output_bit(pin_B2,1);  //GREEN LED OFF
            //lcd_cmd(0xC0);
            //lcd_data("....2TESTING....");
         if((curr_check >= 120) && (curr_check <= 160))
            {  
        ///////  Fan 1 RPM Checking   /////// 
               output_bit(pin_B7,0);
               if(send == 1)
               {
                  for(i=0;i<3000;i++)
                  {
             ///  Volt Checking  ///
                     set_adc_channel(0);
                     delay_us(10);
                     adc_value_volt = read_adc();     
                     measured_volt = (adc_value_volt * ((12.00)/(1023.00)));
                     measured_volt1 = measured_volt * 100;
               
            /// Current Checking ///     
                     measured_curr = measured_volt/75;
                     measured_curr1 = measured_curr * 1000;
                                   
           /// RPM Checking  ///     
                     cycle = pulse_width/5;
                     one_rev = cycle*4;
                     ms_conv = (float)one_rev/1000000;
                     rpm = (60/ms_conv);
                  }               
                  digit_conv_21(measured_volt1, curr_check,rpm);
               }
               
        ///////  Fan 2 RPM Checking   /////// 
        
               output_bit(pin_B7,1);
               if(send == 1)
               {
                  for(i=0;i<1000;i++)
                  {
               
                  ///  Volt Checking  ///
                     set_adc_channel(0);
                     delay_us(10);
                     adc_value_volt = read_adc();     
                     measured_volt = (adc_value_volt * ((12.00)/(1023.00)));
                     measured_volt1 = measured_volt * 100;
            
                  /// Current Checking ///     
                     measured_curr = measured_volt/75;
                     measured_curr1 = measured_curr * 1000;
                  
                  
                  /// RPM Checking  ///     
                     cycle = pulse_width/5;
                     one_rev = cycle*4;
                     ms_conv = (float)one_rev/1000000;
                     rpm = (60/ms_conv);                 
                  }               
                  digit_conv_22(measured_volt1, curr_check,rpm);
                  send = 0;
                  output_bit(pin_B1,0);  // RED LED OFF
                  output_bit(pin_B2,1);  //GREEN LED ON
                  //output_bit(pin_B3,1);  // BUZZER ON
               }
           }
      }
   }
}
      

void digit_conv_01(unsigned long int volt,unsigned int current,unsigned long int rpm)
{
   //unsigned long int volt_conv = volt;
   unsigned int volt1,volt2,volt3,volt4;
   unsigned int curr1,curr2,curr3;
   unsigned int rpm1,rpm2,rpm3,rpm4;
   unsigned long int lcd_curr,lcd_rpm;
   
   
   lcd_curr = current;
   lcd_rpm = rpm;
   
   //volt_conv   = volt *100;
   volt1       = volt / 1000;
   volt   = volt % 1000;
   volt2       = volt / 100;
   volt   = volt % 100;
   volt3       = volt /10;
   volt4       = volt %10;
   
   curr1 = current / 100;
   current = current % 100;
   curr2 = current/10;
   curr3 = current%10;
   
   rpm1 = rpm / 1000;
   rpm = rpm % 1000;
   rpm2 = rpm / 100;
   rpm = rpm % 100;
   rpm3 = rpm / 10;
   rpm4 = rpm %10;
      
      //printf("\r %u%u,1\r\n",volt1,volt2);
     if((volt1 > 0) || (volt2 > 1))
     {
         printf("\r%u%u.%u%u,%u%u%u,%u%u%u%u,01\r\n",volt1,volt2,volt3,volt4,curr1,curr2,curr3,rpm1,rpm2,rpm3,rpm4);
         delay_ms(100);
         
         lcd_cmd(0x80);
         lcd_data("MOD-1");
         lcd_conv_curr1(lcd_curr);
         lcd_conv_rpm1(lcd_rpm);
     }
     
}
void digit_conv_21(unsigned long int volt,unsigned int current,unsigned long int rpm)
{
   unsigned int volt1,volt2,volt3,volt4;
   unsigned int curr1,curr2,curr3;
   unsigned int rpm1,rpm2,rpm3,rpm4;
   unsigned long int lcd_curr,lcd_rpm;
   
   
   lcd_curr = current;
   lcd_rpm = rpm;
   
   //volt_conv   = volt *100;
   volt1       = volt / 1000;
   volt   = volt % 1000;
   volt2       = volt / 100;
   volt   = volt % 100;
   volt3       = volt /10;
   volt4       = volt %10;
   
   curr1 = current / 100;
   current = current % 100;
   curr2 = current/10;
   curr3 = current%10;

   rpm1 = rpm / 1000;
   rpm = rpm % 1000;
   rpm2 = rpm / 100;
   rpm = rpm % 100;
   rpm3 = rpm / 10;
   rpm4 = rpm %10;
      
      //printf("\r %u%u,1\r\n",volt1,volt2);
     if((volt1 > 0) || (volt2 > 1))
     {
         printf("\r%u%u.%u%u,%u%u%u,%u%u%u%u,21\r\n",volt1,volt2,volt3,volt4,curr1,curr2,curr3,rpm1,rpm2,rpm3,rpm4);
         delay_ms(100);
         
         lcd_cmd(0x80);
         lcd_data("MOD-2");
         lcd_conv_curr1(lcd_curr);
         lcd_conv_rpm1(lcd_rpm);
     }
}

void digit_conv_22(unsigned long int volt,unsigned int current,unsigned long int rpm)
{
   unsigned int volt1,volt2,volt3,volt4;
   unsigned int curr1,curr2,curr3;
   unsigned int rpm1,rpm2,rpm3,rpm4;
   unsigned long int lcd_curr,lcd_rpm;
   
   
   lcd_curr = current;
   lcd_rpm = rpm;
   
   //volt_conv   = volt *100;
   volt1       = volt / 1000;
   volt   = volt % 1000;
   volt2       = volt / 100;
   volt   = volt % 100;
   volt3       = volt /10;
   volt4       = volt %10;
   
   curr1 = current / 100;
   current = current % 100;
   curr2 = current/10;
   curr3 = current%10;
   
   rpm1 = rpm / 1000;
   rpm = rpm % 1000;
   rpm2 = rpm / 100;
   rpm = rpm % 100;
   rpm3 = rpm / 10;
   rpm4 = rpm %10;
      
      //printf("\r %u%u,1\r\n",volt1,volt2);
     if((volt1 > 0) || (volt2 > 1))
     {
         printf("\r%u%u.%u%u,%u%u%u,%u%u%u%u,22\r\n",volt1,volt2,volt3,volt4,curr1,curr2,curr3,rpm1,rpm2,rpm3,rpm4);
         delay_ms(100);
         
         lcd_cmd(0x80);
         lcd_data("MOD-2");
         lcd_conv_curr2(lcd_curr);
         lcd_conv_rpm2(lcd_rpm);
     }
}

