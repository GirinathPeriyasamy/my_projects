void lcd_init();
void lcd_cmd(char);
void lcd_data(char);
void lcd_conv_rpm1(long int);
void lcd_conv_curr1(long int);

void lcd_conv_rpm2(long int);
void lcd_conv_curr2(long int);


void lcd_init()
{
output_bit(pin_e2,0);
   lcd_cmd(0x32);
   lcd_cmd(0x28);
   lcd_cmd(0x06);
   lcd_cmd(0x0c);
   lcd_cmd(0x01);
}
void lcd_cmd(char cmd)
{
   output_bit(pin_e2,0);
   output_low(pin_e1);
   output_d(cmd>>4);
   output_high(pin_e0);
   delay_ms(5);
   output_low(pin_e0);
   output_d(cmd&0x0f);
   output_high(pin_e0);
   delay_ms(5);
   output_low(pin_e0);
}
void lcd_data(char data)
{
   output_bit(pin_e2,0);
   output_high(pin_e1);
   output_d(data>>4);
   output_high(pin_e0);
   delay_ms(5);
   output_low(pin_e0);
   output_d(data&0x0f);
   output_high(pin_e0);
   delay_ms(5);
   output_low(pin_e0);
}
void lcd_conv_rpm1(long int i)
{
   long long int a,b,c,d,e,f;
   a=i/1000;
   b=i%1000;
   c=b/100;
   d=b%100;
   e=d/10;
   f=d%10;
   
   
   lcd_cmd(0x86);
   //lcd_data("MOD-1 ");
   lcd_data("RPM:");
   lcd_data(a+0x30);
   lcd_data(c+0x30);
   lcd_data(e+0x30);
   lcd_data(f+0x30);
   lcd_data("   ");
   
  
}
void lcd_conv_curr1(long int i)
{
   long long int a,b,c,d;
   a=i/100;
   b=i%100;
   c=b/10;
   d=b%10;
   
  
   lcd_cmd(0xC0);
   lcd_data("FAN-1 ");
   lcd_data("CURR:");
   lcd_data(a+0x30);
   lcd_data(c+0x30);
   lcd_data(d+0x30);
   lcd_data("mA");
   lcd_data("");
   
}

void lcd_conv_rpm2(long int i)
{
   long long int a,b,c,d,e,f;
   a=i/1000;
   b=i%1000;
   c=b/100;
   d=b%100;
   e=d/10;
   f=d%10;
   
   
//!   lcd_cmd(0x80);
//!   lcd_data("MOD-2 ");
   lcd_cmd(0x86);
   lcd_data("RPM:");
   lcd_data(a+0x30);
   lcd_data(c+0x30);
   lcd_data(e+0x30);
   lcd_data(f+0x30);
   lcd_data("   ");
   
  
}
void lcd_conv_curr2(long int i)
{
   long long int a,b,c,d;
   a=i/100;
   b=i%100;
   c=b/10;
   d=b%10;
   
  
   lcd_cmd(0xC0);
   lcd_data("FAN-2 ");
   //lcd_cmd(0xC6);
   lcd_data("CURR:");
   lcd_data(a+0x30);
   lcd_data(c+0x30);
   lcd_data(d+0x30);
   lcd_data("mA");
   lcd_data("");
   
}
