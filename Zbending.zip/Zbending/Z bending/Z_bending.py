import PIL
import numpy as np
from PIL import Image,ImageTk
import pytesseract
import cv2
from tkinter import *
from tkinter import messagebox
import time


img_counter = 0
width, height = 300, 400
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
cap.set(cv2.CAP_PROP_EXPOSURE,-10)
#print(cap.get(cv2.CAP_PROP_EXPOSURE))

root = Tk()
root.title("Z Bending Inspection")
root.geometry("800x640")
root.bind('<Escape>', lambda e: root.quit())

### Title label - Live video ###
ltitle = Label(root, text ="Live Video", fg ="black", bg="light blue",font = ("Arial",14),borderwidth = 1, relief="solid")
ltitle.pack()
ltitle.place(x=150, y=10)

### Title label - Capture Image ###
ltitle_cap = Label(root, text ="Captured Image", fg ="black", bg="light blue",font = ("Arial",14),borderwidth = 1, relief="solid")
ltitle_cap.pack()
ltitle_cap.place(x=420, y=10)

### Title label - Masked Image ###
ltitle_mask = Label(root, text ="Detected Image", fg ="black", bg="light blue",font = ("Arial",14),borderwidth = 1, relief="solid")
ltitle_mask.pack()
ltitle_mask.place(x=420, y=180)

### Title label - Result Label ###
ltitle_result = Label(root, text ="Inspection Result", fg ="black", bg="light blue",font = ("Arial",14),borderwidth = 1, relief="solid")
ltitle_result.pack()
ltitle_result.place(x=620, y=90)

### Live Camera Video  ###
lmain = Label(root, borderwidth=5, relief="ridge")
lmain.pack()
lmain.place(x=1, y=40)

### Date and Time ###


def Capture_image():
   #msg = messagebox.showinfo( "Hello Python", "Hello World")
    capture_image()

def ExitCall():
    cap.release()
    #cv2.destroyWindow('mask')
    #cv2.destroyWindow('Detection')
    root.destroy()


B = Button(root, text = "Capture", command = Capture_image)
B.place(x = 130,y = 340)

Exit = Button(root, text = "Exit", command = ExitCall)
Exit.place(x = 220,y = 340)

def show_frame():
    _, frame = cap.read()
    #frame = cv2.flip(frame, 1)
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    img = PIL.Image.fromarray(cv2image)
    imgtk = ImageTk.PhotoImage(image=img)
    lmain.imgtk = imgtk
    lmain.configure(image=imgtk)
    lmain.after(10, show_frame)
    time_string = time.strftime('%Y-%m-%d / %H:%M:%S')
    ltime = Label(root, text = "Date/Time = "+str(time_string), font = ("Arial",10), borderwidth = 1, relief="solid")
    #ltime = Label(root)
    ltime.pack()
    ltime.place(x=580, y=10)
     
    
def mask_image(image_original, image_mask):
    
    image_O = cv2.imread(image_original)
    image_M = cv2.imread(image_mask)
    #White color detect
    sought = [255, 255, 255]
    #Black color detect
    #sought = [0, 0, 0]
    result = np.count_nonzero(np.all(image_M==sought,axis=2))
    
    if result < 100:
        print("Fail - Pixes = ", result)
        font = cv2.FONT_ITALIC
        cv2.putText(image_O, "(NG) Pixel ="+str(result),(1,50),font,1,(0,0,0),2,cv2.LINE_4)
        ltitle_OK_NG = Label(root, text ="NG", fg ="red", bg="white",font = ("Arial",70), borderwidth = 1, relief="groove")
        ltitle_OK_NG.pack()
        ltitle_OK_NG.place(x=620, y=190)
    elif result >100:
        font = cv2.FONT_ITALIC
        cv2.putText(image_O, "(OK) Pixel ="+str(result),(1,50),font,1,(0,255,255),2,cv2.LINE_4)
        ltitle_OK_NG = Label(root, text ="OK", fg ="green", bg="white",font = ("Arial",70), borderwidth = 1, relief="groove")
        ltitle_OK_NG.pack()
        ltitle_OK_NG.place(x=620, y=190)
        print("OK - Pixels = ", result)
        
        #### Capture frame ####
        
    ### Capturead Image Show  ###    
    lcapture = Label(root, borderwidth=5, relief="ridge")
    lcapture.pack()
    lcapture.place(x=380, y=40)
    
    ### Masked Image Show  ### 
    lmask = Label(root, borderwidth=5, relief="ridge")
    lmask.pack()
    lmask.place(x=380, y=210)
    
    cv2.imwrite(image_original, image_O)   
    cv2image = cv2.cvtColor(image_O, cv2.COLOR_BGR2RGBA)
    resized = cv2.resize(cv2image, (200,125), interpolation = cv2.INTER_AREA)
    img = PIL.Image.fromarray(resized)
    imgtk = ImageTk.PhotoImage(image=img)
    lcapture.imgtk = imgtk
    lcapture.configure(image=imgtk)
    
    cv2image_M = cv2.cvtColor(image_M, cv2.COLOR_BGR2RGBA)
    resized = cv2.resize(cv2image_M, (200,125), interpolation = cv2.INTER_AREA)
    img = PIL.Image.fromarray(resized)
    imgtk = ImageTk.PhotoImage(image=img)
    lmask.imgtk = imgtk
    lmask.configure(image=imgtk)
    
    
def capture_image():
    
    global img_counter
    ret, frame = cap.read()
    
    #res = cv2.bitwise_and(frame, frame, mask=mask)
    img_name_original = "Z_bending_{}.png".format(img_counter)
    cv2.imwrite(img_name_original,frame)
    print("{} written!".format(img_name_original))

    ### Capturead Image Show  ###    
    lcapture = Label(root, borderwidth=5, relief="ridge")
    lcapture.pack()
    lcapture.place(x=380, y=40)
    
    ### Masked Image Show  ### 
    lmask = Label(root, borderwidth=5, relief="ridge")
    lmask.pack()
    lmask.place(x=380, y=210)
    
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    resized = cv2.resize(cv2image, (200,125), interpolation = cv2.INTER_AREA)
    img = PIL.Image.fromarray(resized)
    imgtk = ImageTk.PhotoImage(image=img)
    lcapture.imgtk = imgtk
    lcapture.configure(image=imgtk)

    img_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    template = cv2.imread('template.jpg',0)
    w, h = template.shape[::-1]

    res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)

    threshold = 0.26
    loc = np.where( res >= threshold)
    
    for pt in zip(*loc[::-1]):
        cv2.rectangle(frame, pt, (pt[0] + w, pt[1] + h), (0,255,255), 2)

    cv2image_M = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
##    if cv2image.shape == cv2image_M.shape:
##        print("Shape is equal")
##        difference = cv2.subtract(cv2image, cv2image_M)
##        #b, g, r = cv2.split(difference)
##
##        #print(cv2.countNonZreo(b))
##        if cv2.countNonZero(b) == 0 and cv2.countNonZero(g) == 0 and cv2.countNonZero(r) == 0:
##            print("Images is Equal")
    resized = cv2.resize(cv2image_M, (200,125), interpolation = cv2.INTER_AREA)
    img = PIL.Image.fromarray(resized)
    imgtk = ImageTk.PhotoImage(image=img)
    lmask.imgtk = imgtk
    lmask.configure(image=imgtk)

    #cv2.imshow('Detected',img_name_original)
    
    #mask_image(img_name_original,img_name_mask)
    img_counter += 1
    
show_frame()
root.mainloop()
