import PIL
import numpy as np
from PIL import Image, ImageTk
import pytesseract
import cv2
from tkinter import *
from tkinter import messagebox
import time
import serial

IO_serial = serial.Serial('/dev/ttyUSB0',19200)
img_counter = 0
width, height = 300, 400
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
cap.set(cv2.CAP_PROP_EXPOSURE,-10)
#print(cap.get(cv2.CAP_PROP_EXPOSURE))

root = Tk()
root.title("Z Bending Inspection")
root.geometry("800x640")
root.bind('<Escape>', lambda e: root.quit())

### Title label - Live video ###
ltitle = Label(root, text ="Live Video", fg ="black", bg="light blue",font = ("Arial",14),borderwidth = 1, relief="solid")
ltitle.pack()
ltitle.place(x=150, y=10)

### Title label - Capture Image ###
ltitle_cap = Label(root, text ="Captured Image", fg ="black", bg="light blue",font = ("Arial",14),borderwidth = 1, relief="solid")
ltitle_cap.pack()
ltitle_cap.place(x=420, y=10)

### Title label - Masked Image ###
ltitle_mask = Label(root, text ="Detected Image", fg ="black", bg="light blue",font = ("Arial",14),borderwidth = 1, relief="solid")
ltitle_mask.pack()
ltitle_mask.place(x=420, y=180)

### Title label - Result Label ###
ltitle_result = Label(root, text ="Inspection Result", fg ="black", bg="light blue",font = ("Arial",14),borderwidth = 1, relief="solid")
ltitle_result.pack()
ltitle_result.place(x=620, y=90)

### Live Camera Video  ###
lmain = Label(root, borderwidth=5, relief="ridge")
lmain.pack()
lmain.place(x=1, y=40)

ltitle_OK_NG = Label(root, text ="", fg ="white", bg="white",font = ("Arial",70), borderwidth = 1, relief="groove")
ltitle_OK_NG.pack()
ltitle_OK_NG.place(x=620, y=190)

lthreshold = Label(root, text ="Threshold", fg ="black", bg="light blue",font = ("Arial",10), borderwidth = 1, relief="solid")
lthreshold.pack()
lthreshold.place(x=50, y=380)

### Capturead Image Show  ###    
lcapture = Label(root, borderwidth=5, relief="ridge")
lcapture.pack()
lcapture.place(x=380, y=40)
    
### Masked Image Show  ### 
lmask = Label(root, borderwidth=5, relief="ridge")
lmask.pack()
lmask.place(x=380, y=210)

TextBox = Text(root, height=1, width=10)
TextBox.pack()
TextBox.place(x=130, y=380)
TextBox.insert(INSERT,"0.92")

### Date and Time ###


def Capture_image():
   #msg = messagebox.showinfo( "Hello Python", "Hello World")
    capture_image()

def ExitCall():
    cap.release()
    #cv2.destroyWindow('mask')
    #cv2.destroyWindow('Detection')
    root.destroy()
    
def template_matching( master_img, capture_img_gray, capture_img):
    #captured_img = capture_img
    #cv2.imshow("Original1", captured_img)
    w, h = master_img.shape[::-1]
    res = cv2.matchTemplate(capture_img_gray,master_img,cv2.TM_CCOEFF_NORMED)
    #threshold = 0.575
    threshold = TextBox.get("1.0", END)
    print(threshold)
    loc = np.where( res >= threshold)
    for pt in zip(*loc[::-1]):
        cv2.rectangle(capture_img, pt, (pt[0] + w, pt[1] + h), (0,255,255), 2)
    
    cv2.imwrite(detected_image, capture_img)   
    cv2.imshow('Detected',img_rgb)
    
def image_compare():
    original = cv2.imread("Z_bending.jpg")
    duplicate = cv2.imread("detected.jpg")
    
    if original.shape == duplicate.shape:
        #print("The images have same size and channels")
        difference = cv2.subtract(original, duplicate)
        b, g, r = cv2.split(difference)
    
        if cv2.countNonZero(b) == 0 and cv2.countNonZero(g) == 0 and cv2.countNonZero(r) == 0:
            #print("NG")
            ltitle_OK_NG.configure(text = 'NG', bg = "red")
        else:
            #print("OK")
            ltitle_OK_NG.configure(text = 'OK', bg = "green")
    
B = Button(root, text = "Capture", command = Capture_image)
B.place(x = 130,y = 340)

Exit = Button(root, text = "Exit", command = ExitCall)
Exit.place(x = 220,y = 340)

def show_frame():
    _, frame = cap.read()
    #frame = cv2.flip(frame, 1)
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    img = PIL.Image.fromarray(cv2image)
    imgtk = ImageTk.PhotoImage(image=img)
    lmain.imgtk = imgtk
    lmain.configure(image=imgtk)
    lmain.after(10, show_frame)
    time_string = time.strftime('%Y-%m-%d / %H:%M:%S')
    #ltime = Label(root, text = "Date/Time = "+str(time_string), font = ("Arial",10), borderwidth = 1, relief="solid")
    #ltime = Label(root)
    #ltime.pack()
    #ltime.place(x=580, y=10)
    rece_data = IO_serial.read_all()
    R_data_len = len(rece_data)
    if R_data_len > 3:
        if rece_data[1] == 48 and rece_data[2] == 49:
            capture_image()
            #print(rece_data)
     
        
def capture_image():
    
    global img_counter
    ret, frame = cap.read()
    
    #res = cv2.bitwise_and(frame, frame, mask=mask)
    #img_name_original = "Z_bending_{}.png".format(img_counter)
    img_name_original = "Z_bending.jpg".format(img_counter)
    cv2.imwrite(img_name_original,frame)
    #print("{} written!".format(img_name_original))

    
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    resized = cv2.resize(cv2image, (200,125), interpolation = cv2.INTER_AREA)
    img = PIL.Image.fromarray(resized)
    imgtk = ImageTk.PhotoImage(image=img)
    lcapture.imgtk = imgtk
    lcapture.configure(image=imgtk)

    img_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    template = cv2.imread('template.jpg',0)
    w, h = template.shape[::-1]

    res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)

    threshold = TextBox.get("1.0", END)
    threshold = float(threshold)
    #print(threshold)
    loc = np.where( res >= threshold)
    
    for pt in zip(*loc[::-1]):
        cv2.rectangle(frame, pt, (pt[0] + w, pt[1] + h), (0,255,255), 2)
    cv2.imwrite("detected.jpg", frame)
    
    cv2image_M = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    
    #template_matching(template, img_gray, img_name_original)
    image_compare()

    resized = cv2.resize(cv2image_M, (200,125), interpolation = cv2.INTER_AREA)
    img = PIL.Image.fromarray(resized)
    imgtk = ImageTk.PhotoImage(image=img)
    lmask.imgtk = imgtk
    lmask.configure(image=imgtk)

    #cv2.imshow('Detected',img_name_original)
    
    #mask_image(img_name_original,img_name_mask)
    img_counter += 1
    
show_frame()
root.mainloop()
