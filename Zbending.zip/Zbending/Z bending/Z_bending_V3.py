import PIL
import numpy as np
from PIL import Image,ImageTk
import pytesseract
import cv2
from tkinter import *
from tkinter import messagebox
import time
import serial

IO_serial = serial.Serial('/dev/ttyUSB0',19200)
#IO_serial = serial.Serial('COM1',19200)
img_counter = 0
width, height = 300, 400

cap = cv2.VideoCapture(0)
cap1 = cv2.VideoCapture(2)
#cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
#cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
#cap.set(cv2.CAP_PROP_EXPOSURE,-6)
#print(cap.get(cv2.CAP_PROP_EXPOSURE))

root = Tk()
root.title("Z Bending Tool Inspection")
root.geometry("800x440")
root.bind('<Escape>', lambda e: root.quit())

### Title label - Live video ###
ltitle = Label(root, text ="  Z Bending Tool Inspection  ", fg ="yellow", bg="black",font = ("Arial",14),borderwidth = 0, relief="solid")
ltitle.pack()
ltitle.place(x=300, y=0)

### Title label - Live video ###
ltitle_tool1 = Label(root, text ="Captured Image Tool-1", fg ="black", bg="light blue",font = ("Arial",10),borderwidth = 1, relief="solid")
ltitle_tool1.pack()
ltitle_tool1.place(x=50, y=30)

### Title label - Capture Image ###
ltitle_tool2 = Label(root, text ="Captured Image Tool-2", fg ="black", bg="light blue",font = ("Arial",10),borderwidth = 1, relief="solid")
ltitle_tool2.pack()
ltitle_tool2.place(x=350, y=30)

### Title label - Capture Image ###
ltitle_template = Label(root, text ="Template Image", fg ="black", bg="light blue",font = ("Arial",10),borderwidth = 1, relief="solid")
ltitle_template.pack()
ltitle_template.place(x=645, y=60)

### Title label - Masked Image ###
ltitle_tool1_condition = Label(root, text ="Tool-1 Condition", fg ="black", bg="light blue",font = ("Arial",10),borderwidth = 1, relief="solid")
ltitle_tool1_condition.pack()
ltitle_tool1_condition.place(x=50, y=195)

### Title label - Masked Image ###
ltitle_tool2_condition = Label(root, text ="Tool-2 Condition", fg ="black", bg="light blue",font = ("Arial",10),borderwidth = 1, relief="solid")
ltitle_tool2_condition.pack()
ltitle_tool2_condition.place(x=350, y=195)

### Title label - Result Label ###
ltitle_result = Label(root, text ="Inspection Result", fg ="black", bg="light blue",font = ("Arial",10),borderwidth = 1, relief="solid")
ltitle_result.pack()
ltitle_result.place(x=50, y=360)

### Title label - Result Label ###
ltitle_result1 = Label(root, text ="Inspection Result", fg ="black", bg="light blue",font = ("Arial",10),borderwidth = 1, relief="solid")
ltitle_result1.pack()
ltitle_result1.place(x=350, y=360)

ltitle_OK_NG = Label(root, text ="", fg ="white", bg="white",font = ("Arial",25), borderwidth = 1, relief="groove")
ltitle_OK_NG.pack()
ltitle_OK_NG.place(x=50, y=383)

ltitle_OK_NG1 = Label(root, text ="", fg ="white", bg="white",font = ("Arial",25), borderwidth = 1, relief="groove")
ltitle_OK_NG1.pack()
ltitle_OK_NG1.place(x=350, y=383)

lthreshold = Label(root, text ="Threshold", fg ="black", bg="light blue",font = ("Arial",10), borderwidth = 1, relief="solid")
lthreshold.pack()
lthreshold.place(x=635, y=340)

TextBox = Text(root, height=1, width=10)
TextBox.pack()
TextBox.place(x=700, y=340)


def ExitCall():
    cap.release()
    cap1.release()
    IO_serial.close()
    #cv2.destroyWindow('mask')
    #cv2.destroyWindow('Detection')
    root.destroy()
    
def image_compare_1():
    original = cv2.imread("Z_bending.jpg")
    duplicate = cv2.imread("detected.jpg")
    
    if original.shape == duplicate.shape:
        #print("The images have same size and channels")
        difference = cv2.subtract(original, duplicate)
        b, g, r = cv2.split(difference)
    
        if cv2.countNonZero(b) == 0 and cv2.countNonZero(g) == 0 and cv2.countNonZero(r) == 0:
            #print("NG")
            ltitle_OK_NG.configure(text = '   NG   ', bg = "red")
        else:
            #print("OK")
            ltitle_OK_NG.configure(text = '   OK   ', bg = "green")
            
def image_compare_2():
    original = cv2.imread("Z_bending1.jpg")
    duplicate = cv2.imread("detected1.jpg")
    
    if original.shape == duplicate.shape:
        #print("The images have same size and channels")
        difference = cv2.subtract(original, duplicate)
        b, g, r = cv2.split(difference)
    
        if cv2.countNonZero(b) == 0 and cv2.countNonZero(g) == 0 and cv2.countNonZero(r) == 0:
            #print("NG")
            ltitle_OK_NG1.configure(text = '   NG   ', bg = "red")
        else:
            #print("OK")
            ltitle_OK_NG1.configure(text = '   OK   ', bg = "green")
    
   
def capture_image():
    
    global img_counter
    ret, frame = cap.read()
    ret1, frame1 = cap1.read()
    #ret1, frame1 = cap1.read()
    
    #res = cv2.bitwise_and(frame, frame, mask=mask)
    #img_name_original = "Z_bending_{}.png".format(img_counter)
    img_name_original = "Z_bending.jpg".format(img_counter)
    img_name_original1 = "Z_bending1.jpg".format(img_counter)
    
    cv2.imwrite(img_name_original,frame)
    cv2.imwrite(img_name_original1,frame1)
    #print("{} written!".format(img_name_original))
    #print("{} written!".format(img_name_original1))

    ### Capturead Image Show  ###    
    lcapture_tool1 = Label(root, borderwidth=5, relief="ridge")
    lcapture_tool1.pack()
    lcapture_tool1.place(x=10, y=55)
    
    ### Capturead Image Show  ###    
    lcapture_tool2 = Label(root, borderwidth=5, relief="ridge")
    lcapture_tool2.pack()
    lcapture_tool2.place(x=300, y=55)
    
    ### Template Image Show  ###    
    ltemplate = Label(root, borderwidth=5, relief="ridge")
    ltemplate.pack()
    ltemplate.place(x=580, y=90)
    
    
    
    ### Masked Image Show  ### 
    lmask_tool1 = Label(root, borderwidth=5, relief="ridge")
    lmask_tool1.pack()
    lmask_tool1.place(x=10, y=220)
    
     ### Masked Image Show  ### 
    lmask_tool2 = Label(root, borderwidth=5, relief="ridge")
    lmask_tool2.pack()
    lmask_tool2.place(x=300, y=220)
    
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    resized = cv2.resize(cv2image, (200,125), interpolation = cv2.INTER_AREA)
    img = PIL.Image.fromarray(resized)
    imgtk = ImageTk.PhotoImage(image=img)
    lcapture_tool1.imgtk = imgtk
    lcapture_tool1.configure(image=imgtk)
    
    cv2image = cv2.cvtColor(frame1, cv2.COLOR_BGR2RGBA)
    resized = cv2.resize(cv2image, (200,125), interpolation = cv2.INTER_AREA)
    img = PIL.Image.fromarray(resized)
    imgtk = ImageTk.PhotoImage(image=img)
    lcapture_tool2.imgtk = imgtk
    lcapture_tool2.configure(image=imgtk)


    img_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    img_gray1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
    template = cv2.imread('template.jpg',0)
    w, h = template.shape[::-1]

    res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)
    res1 = cv2.matchTemplate(img_gray1,template,cv2.TM_CCOEFF_NORMED)

    threshold = TextBox.get("1.0", END)
    threshold = float(threshold)
    #print(threshold)
    loc = np.where( res >= threshold)
    
    for pt in zip(*loc[::-1]):
        cv2.rectangle(frame, pt, (pt[0] + w, pt[1] + h), (0,255,255), 2)
    cv2.imwrite("detected.jpg", frame)
    
    cv2image_M = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    
    loc1 = np.where( res1 >= threshold)
    
    for pt1 in zip(*loc1[::-1]):
        cv2.rectangle(frame1, pt1, (pt1[0] + w, pt1[1] + h), (0,255,255), 2)
    cv2.imwrite("detected1.jpg", frame1)
    
    cv2image_M1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2RGBA)
    
    image_compare_1()
    image_compare_2()

    resized = cv2.resize(cv2image_M, (200,125), interpolation = cv2.INTER_AREA)
    img = PIL.Image.fromarray(resized)
    imgtk = ImageTk.PhotoImage(image=img)
    lmask_tool1.imgtk = imgtk
    lmask_tool1.configure(image=imgtk)
    
    resized1 = cv2.resize(cv2image_M1, (200,125), interpolation = cv2.INTER_AREA)
    img1 = PIL.Image.fromarray(resized1)
    imgtk1 = ImageTk.PhotoImage(image=img1)
    lmask_tool2.imgtk1 = imgtk1
    lmask_tool2.configure(image=imgtk1)
    
    resized2 = cv2.resize(template, (200,175), interpolation = cv2.INTER_AREA)
    img2 = PIL.Image.fromarray(resized2)
    imgtk2 = ImageTk.PhotoImage(image=img2)
    ltemplate.imgtk2 = imgtk2
    ltemplate.configure(image=imgtk2)
    
    
def show_frame():
    _, frame = cap.read()
    _, frame1 = cap1.read()
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    img = PIL.Image.fromarray(cv2image)
    imgtk = ImageTk.PhotoImage(image=img)
    ltitle.after(7, show_frame)
    
    rece_data = IO_serial.read_all()
    R_data_len = len(rece_data)
    if R_data_len > 3:
        if rece_data[1] == 48 and rece_data[2] == 49:
            capture_image()
            print(rece_data)
            #print(len(rece_data))
    elif R_data_len == 17:
        print
        
B = Button(root, text = "Capture", command = capture_image)
B.place(x = 640,y = 400)

Exit = Button(root, text = "Exit", command = ExitCall)
Exit.place(x = 730,y = 400)

show_frame()
root.mainloop()
